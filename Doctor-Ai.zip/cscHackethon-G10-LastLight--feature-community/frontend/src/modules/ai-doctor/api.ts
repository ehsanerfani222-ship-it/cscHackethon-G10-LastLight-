import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export const consultAIDoctor = async (payload: {
  category: string; symptom: string; bodyArea: string; severity: number; age: number; additionalInfo?: string;
}) => {
  const { data } = await api.post('/doctor/consult', payload);
  return data;
};

export const getConsultationHistory = async () => {
  const { data } = await api.get('/doctor/history');
  return data;
};

export const getConsultation = async (id: string) => {
  const { data } = await api.get(`/doctor/history/${id}`);
  return data;
};

export const updateConsultation = async (id: string, additionalInfo: string) => {
  const { data } = await api.put(`/doctor/history/${id}`, { additionalInfo });
  return data;
};

export const deleteConsultation = async (id: string) => {
  const { data } = await api.delete(`/doctor/history/${id}`);
  return data;
};
